<?php

$servername = "localhost";
$username = "mmartins";
$password = "r1xsW88uqxm4";
$dbname = "myDB";

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}


$name = $_POST['name'];
$email = $_POST['email'];
$comment = $_POST['comment'];


$sql = "INSERT INTO contacts (name, email, comment) VALUES ('$name', '$email', '$comment')";

if (mysqli_query($conn, $sql)) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}

mysqli_close($conn);
?>
