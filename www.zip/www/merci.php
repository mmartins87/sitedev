<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>CodePen -  Css quote animation + Tailwindcss</title>
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.1.4/tailwind.min.css'><link rel="stylesheet" href="./merci.css">

</head>
<body>
<!-- partial:index.partial.html -->
<div class="min-h-screen bg-gray-100 py-6 flex flex-col justify-center sm:py-12">
  <div class="relative py-3 sm:max-w-3xl sm:mx-auto group card">
    <!-- Quotes -->
    <svg class="absolute transform -left-12 -top-12" width="100" height="78" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path fill-rule="evenodd" clip-rule="evenodd" d="M100 0H86.588L59.034 40.478v37.065h37.064V40.478H82.2L100 0zM40.966 0H27.554L0 40.478v37.065h37.064V40.478H23.165L40.965 0z" fill="#871EFF"/>
    </svg>
    <svg class="absolute transform -right-12 -bottom-6 flip" width="101" height="78" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M14.2916 77.9999H0.880127L18.6808 37.5217H4.78164V0.457275H41.846V37.5217L14.2916 77.9999Z" fill="#871EFF"/>
      <path d="M73.4115 78H60L77.8007 37.5218H63.9015V0.457397H100.966V37.5219L73.4115 78Z" fill="#871EFF"/>
    </svg>
    <!-- Card -->
    <div class="flex flex-row relative bg-white shadow-xl">
      <div class="border-gray-800 border-8 bg-center w-full h-72 bg-no-repeat bg-center bg-cover" style="background-image: url(/UwAmp/www/assets/imgs/man.png)"></div>
      <div class="relative px-4 py-6 sm:p-10 w-3/2 flex flex-wrap content-center">
          <div class="space-y-3">
            <p class='italic text-xl text-gray-800' >Je tenais à vous remercier chaleureusement pour votre réponse au formulaire. Votre participation est d'une grande valeur pour nous et nous sommes très reconnaissants pour votre temps et votre contribution.</br>

Nous avons bien pris note de votre réponse et nous sommes impatients de répondre à vos besoins et attentes au mieux de nos capacités. Nous allons étudier votre réponse avec attention et nous y répondrons dans les plus brefs délais.</p>
            <div class="space-y-0">
              <p class="text-xl text-purple-500 ">Mathéo Martins</p>
              <p class="text-base text-gray-500 ">Web Designer</p>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
<!-- partial -->
  
</body>
</html>
