<?php
if (isset($_POST['submit'])) {
  $name = $_POST['name'];
  $email = $_POST['email'];
  $comment = $_POST['comment'];
  
  $message = "Merci de votre message, $name! Nous avons bien reçu votre adresse email ($email) et votre message ($comment).";
  echo $message;
  

  header('Location: merci.php');
  exit();
}
?>
